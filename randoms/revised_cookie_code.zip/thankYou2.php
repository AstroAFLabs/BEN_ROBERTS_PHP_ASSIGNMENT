<!DOCTYPE = html>


	<?php
		print_r($_COOKIE);  //Prints all your cookie values
		echo "<h1>Product ID Update</h1>";
		echo "<p>Thank you, your data has been processed</p>";
		
		if(isset($_COOKIE['itemNo']))
		{
			echo "<p>New Product ID is : ". $_COOKIE['itemNo']. "</p>";
		}
		else
		{
			echo "<p>Sorry... cannot retrieve ID at this time" . "</P>";
		}
		
		
	?>
	<html>

		<head>
			<meta charset="UTF-8">
			<title>Product ID Update</title>	
		</head>

		<body>
			
			<a href='acmePortal2.php'>Return to Acme Product Portal</a>
		</body>
	</html>