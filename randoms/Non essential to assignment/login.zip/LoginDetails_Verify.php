<?php 

/*WEBPHP ASSIGNMENT BEN ROBERTS
000726910
09/12/2022
name of file: LoginDetails_Verify.php

This file collects and adds staff login details to the acme door levers DB, upon verification and password encryption*/

	//error messages hidden

	ini_set('display_errors', 0);
	ini_set('display_startup_errors', 0);
	error_reporting(-1); 
 
	//Connect to the database server using the syntax mysqli_connect(server, username, password)
	
	
	
	 $conn = @mysqli_connect("localhost:3306", "root", "");
	 
	 if (!$conn) {
		echo "The connection has failed: " . mysqli_error($conn);
	 }
	else 
	{
				$dbName = "acme_door_levers";
				$query = "CREATE DATABASE IF NOT EXISTS ".$dbName;
				
				if(!mysqli_query($conn, $query)){
		
					echo"<p>Could not open the database: ".mysqli_error($conn)."</p>";
				}
				else
				{
					if(!mysqli_select_db($conn,$dbName)){
						
					echo"<p>Couldn't open the database: ".mysqli_error($conn)."</p>";}
					else
					{
						
					$query = "CREATE TABLE IF NOT EXISTS staff_logins (userName varchar(50) not null primary key 							,userPassword varchar(255) not null)";
				if (!mysqli_query($conn,$query)) 
				{
					echo "<p>table query failed: " . mysqli_error($conn)."</p>";
				}
				else 
				{	
					$userName = $_POST['userName'];
					$userPassword = $_POST['userPassword'];
					
					$query = "SELECT * FROM staff_logins WHERE userName='".$userName."'";
					$results = mysqli_query($conn,$query);
					if ($results) 
					{
						$numRecords=mysqli_num_rows($results);
						if ($numRecords != 0) //found a match with the username
						{
							//need to verify user - check the password
							$row = mysqli_fetch_array($results);
							$hashedPassword = $row['userPassword'];
							//$myHashedPassword = password_hash($myPassword, PASSWORD_DEFAULT);
							$passwordsAreTheSame = password_verify($userPassword,$hashedPassword);
							
							if ($passwordsAreTheSame == true)
							{
								echo 	"<!doctype html>";
								echo	"<html lang ='en'>";
								echo	"<head>";
								echo	"<meta charset='utf-8'>";
								echo	"<body>";
								echo	"<div>";
								echo	"<h1>Passwords match!</h1>";
								echo	"<a href='acmePortal.php'>Acme Portal<a>";
								echo 	"</div>";
								echo	"</body>";
								echo	"</html>";
							}
							 else
							{
								echo 	"<!doctype html>";
								echo	"<html lang ='en'>";
								echo	"<head>";
								echo	"<meta charset='utf-8'>";
								echo 	"<link rel='stylesheet' type='text/css' href='METAKRON.css'>";
								echo	"<body>";
								echo	"<div>";
								echo	"<h1>Username exists but the password does not match.";
								//echo	"<p><a href='login.php'>Return to login page<a></p>";
								echo	"<hr>";
							
							echo "<div><h1>This user does not exist in the database.</div></h1>";
							echo "<h3>Would you like to enter this user into the database?</h3>";
							echo "<p class='paragraphACME'><a href='staffDetailsUpdate.php'>Yes</a></p>";
							echo "</div>";
							echo "<div>";
							echo "<p class='paragraphACME'><a href='http://google.com' target='popup' onclick='window.open('http://google.com','popup','width=600,height=600'); return false;'>No? OK! have a nice day!</a></p>";
							
							echo "</div>";
							echo"</body>";
							echo"</html>";
							
							
							$hashedPassword = password_hash($userPassword,PASSWORD_DEFAULT);
							//insert data in the table
							$insert = "INSERT INTO staff_logins(userName, userPassword) VALUES ('$userName', '$hashedPassword')";

							if (mysqli_query($conn,$insert)) 
							{
								//update successful
								echo "<p>New user added</p>"; 
							}
							else 
							{
								echo "<p>table query failed: " . mysqli_error($conn)."</p>";
							}
						}
						
						
							$benPassword = "unbreakablepassword";
							$hashedBenPassword = password_hash($benPassword,PASSWORD_DEFAULT);
							
							//insert data in the table
							$insert = "INSERT INTO staff_logins(userName, userPassword) VALUES ('Ben Roberts', '$hashedBenPassword')";

							if (mysqli_query($conn,$insert)) 
							{
								//update successful
								echo "<p>New user added</p>"; 
								
							}
							else 
							{
								echo "<p>table query failed: " . mysqli_error($conn)."</p>";
							}
						}	
					}
					/* else
					{
						echo "<p>Error locating customer details</p>";
					} */
				}
			}
		}
	}
	
	//Close the connection
	mysqli_close($conn);
?>

