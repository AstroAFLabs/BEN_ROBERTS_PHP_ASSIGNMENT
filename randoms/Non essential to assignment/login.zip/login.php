<!DOCTYPE html>

<?php 

/*WEBPHP ASSIGNMENT BEN ROBERTS
000726910
09/12/2022

FILENAME: login.php
This file collects and stores user logins to the acme door levers DB.*/

		

		$errMessageUserName="required field"; //this needs to be outside of the if statement otherwise 													    //this will not be recognised in the form tags
		$errMessageUserPassword="required field"; 
		$userName ="";
		$userPassword ="";
		
		if ($_SERVER["REQUEST_METHOD"] == "POST") {  //User has pressed the submit button
		if(isset($_POST["reset"])){
			header("Refresh:0");
			exit();
		}
			
			
			
			$userName = checkInput($_POST["userName"]);
			$userPassword = checkInput($_POST["userPassword"]);
			$errMessageUserName = "";
			$errMessageUserPassword = "";
			
			
			
			$validData = true;

			
			if($userName == "") {
				$errMessageUserName="Please enter your name.";
				$validData = false;
			}
			
			if($userPassword == "") {
				$errMessageUserPassword="You must enter your password";
				$validData = false;
			}
			
			if ($validData) {
				include("LoginDetails_Verify.php");
				exit();
			}
		}
		
		 function checkInput($inputData) {
			$inputData = trim($inputData);
			$inputData = stripslashes($inputData);
			$inputData = htmlspecialchars($inputData);
			return $inputData; 
		 }

/*WEBPHP ASSIGNMENT BEN ROBERTS
000726910
09/12/2022
name of file: LoginDetails_Verify.php

This file collects and adds staff login details to the acme door levers DB, upon verification and password encryption*/

 
	//Connect to the database server using the syntax mysqli_connect(server, username, password)

	?>
<html lang="en">
<head>
<meta charset="utf-8" >
<link rel="stylesheet" type="text/css" href="METAKRON.css">
<link rel="stylesheet" type="text/css" href="uikit.css">

<title>Acme Staff Login Page</title>
</head>
<header class=" header uk-animation-slide-right">ACME Ceramics Pty Ltd</header> 
<body class="uk-background-width-1-1">
<section>
<div class="uk-card uk-card-default uk-card-center box uk-card-primary">

<h1 class="uk-article-title">Staff Login</h1>

<p>

<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
<label for="userName">Name</label>
<input type="text" id="userName" name="userName" value="<?php echo $userName;?>"/><span class="error">*<?php echo $errMessageUserName;?></span></br></br>
<p><label for="userPassword">Login ID</label></p>
<input type="password" id="userPassword" name="userPassword" /><span class="error">*<?php echo $errMessageUserPassword;?></span></br></br>


<label for="submitDetails">SUBMIT DETAILS</label><input type="submit" name="submit" value="Login"/>
<label for="resetForm">RESET FORM</label><input type="reset" name="reset" value="Reset Form"/>
</form>
<hr>
<p>Enter new user details</p>
<button type="button" background-color="green" name="newUser" value="New User"/>
<a href="staffDetailsUpdate.php" value="staffUpdate">Update Details here
</a>
</button>

</p>
</div>

</section>

<footer>ACME Ceramics Pty Ltd</footer>
</body>

</html>
