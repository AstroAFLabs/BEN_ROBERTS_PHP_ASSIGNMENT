




<!DOCTYPE html>

<html lang="en">
	<head>
	
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="uikit.css">
	<link rel="stylesheet" type="text/css" href="METAKRON.css">

	<title>Upload a File</title>
	</head>
	
	
	<header class=" header uk-animation-slide-right">ACME Ceramics Pty Ltd</header> 
<body>
<div hidden>
<?php

/* WEBPHP Assignment 4
DOOR LEVER INVENTORY ASSIGNMENT
BEN ROBERTS 000726910
12/12/22

FILENAME: acmePortal.php
This is the main entry page for staff or users to access the acme door levers database.  */

     
		ini_set('display_errors', 0);
		ini_set('display_startup_errors', 0);
		error_reporting(-1); 
		
	include ('initialiseDB.php');

	if($_SERVER["REQUEST_METHOD"]== "POST"){
	
		
		$productName = $_POST['productName'];
		$description = $_POST['description']; 
		$color = $_POST['color'];
		$finish = $_POST['finish'];
		$price = $_POST['price'];


		if (!$_POST['productName']){{
				
				echo "<p>You must enter a product name.</p>";
				//echo "<a href="acmePortal.php">Return to details form</a>";
				}
				
		if (!$_POST['description']){
			
				echo "<p>Please enter a product description. </p>";
				//echo "<a href="acmePortal.php">Return to details form</a>";
				}
				
		if (!$_POST['color']){
			
				echo "<p>Please enter the product color</p>";
				//echo "<a href='acmePortal.php'>Return to details form</a>";
				}
				
		if (!$_POST["finish"]){
			
				echo "<p>Please enter the product finish type</p>";
				//echo "<a href='acmePortal.php'>Return to details form</a>";
				}
				
		if (!$_POST["price"]){
			
				echo "<p>Please enter the product value: </p>";
				
		}}
				
			else 
			{
				echo "<p>Form has been submitted for processing</p>";
				echo "<a href='acmePortal.php'>Return to details form</a>";
				}
		}
	

?>	
</div>

<section class="article">
<div class="uk-card uk-card-default">
<h1>Product Upload Page</h1>
	
<div class="uk-card-default">

	
		<h2>Acme Door Levers</h2>
		
		<h3>Product Detail Form</h3>
		
		
		
		<form class="uk-default paragraphACME" method='POST' action="storefile.php"  enctype="multipart/form-data">
		
		
		<p><label for="productName">Product Name</label><input type="text" id="productName" name="productName"></p>
		<p>Product Description
		<label for="description"><textarea rows="5" cols="50" id="description" name="description" placeholder="Please enter a product description">Please provide a short description of the product</textarea></label></p>
		<p><label for="color">Product Colour</label><input type="color" id="color" name="color"></p>
		<p>Product Finish
		<label for="finish"><select id="finish" name="finish"></label>
		<option value="Brushed Chrome">Brushed Chrome</option>
		<option value="Brushed Zinc">Brushed Zinc</option>
		<option value="Matte">Matte</option>
		<option value="Pewter">Pewter</option>
		<option value="Polished Brass">Polished Brass</option>
		<option value="Rustic">Rustic</option>
		<option value="Pioneer">Pioneer</option>
		<option value="East Coast">East Coast</option>
		</select></p>
		<label for="price">Price</label>
		<input type="number" id="price" name="price" value="1" max=
		"200">
		<div class="uk-card-default">
		<p><input type='hidden' name='MAX_FILE_SIZE' value='41943040'></p>
		<p><label for="userfile">Send this file</label></p>
		<p><input type="file" id="userfile" name="userfile"/></p>
		<p>
		<input type="submit"  id="SendFile" name = "Send File"  value= "Send File"></p>
		<p><label for="resetFile">CLear Form</label><input type="reset" id="resetFile" name= "reset" value= "Clear form"></p>
		</div>
		
		</form>
		<ul>
		<li><a href="priceChange.php" target="external">Update Product/price</a></li>
		<li><label for="details">Update Staff Details</label<a href="staffDetailsUpdate.php" target="external"></a></li>
		<li><a href="deleteProduct.php" target="external">Remove Product</a></li>
		</ul>
		</div>
		
	</div>
	
	</section>
	</body>
</html>
	